# YouTube Agent Studio — MVP

Painel web independente para operar uma equipe de 11 agentes de YouTube. Esta primeira entrega implementa o **Roteirista**; os outros dez agentes já estão registrados no catálogo e entram em etapas posteriores.

## O que está funcionando
- Interface web em português.
- Endpoint `GET /api/agents` com os 11 agentes.
- Endpoint `POST /api/script` para gerar cinco hooks, pontuar cada hook, montar roteiro por cena, sugerir títulos, descrição e hashtags.
- Modo demonstração sem chave de API.
- Integração opcional com OpenAI pelo backend. A chave nunca vai para o navegador.
- Perfil de voz e campo para fatos/fontes fornecidos pelo usuário.
- Avisos para não tratar score heurístico como previsão de viralização.

## Executar localmente
Requer Python 3.11+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# coloque OPENAI_API_KEY no ambiente ou carregue o .env com sua ferramenta
uvicorn app.main:app --reload
```

Abra http://localhost:8000

Para configurar a chave sem biblioteca adicional:
```bash
export OPENAI_API_KEY="sua-chave"
export OPENAI_MODEL="gpt-6-luna"
```

No PowerShell:
```powershell
$env:OPENAI_API_KEY="sua-chave"
$env:OPENAI_MODEL="gpt-6-luna"
```

Sem `OPENAI_API_KEY`, o sistema usa um roteiro demonstrativo local. Para produção, configure autenticação, banco de dados, limites de uso, logs e gestão segura de segredos antes de disponibilizar publicamente.

## API
`POST /api/script`

Exemplo:
```json
{
  "topic": "Por que seu salário desaparece antes do fim do mês?",
  "audience": "Adultos que querem organizar o orçamento",
  "format": "YouTube Shorts",
  "duration_seconds": 40,
  "tone": "Direto, didático e envolvente",
  "goal": "Ensinar uma ação prática"
}
```

## Arquitetura planejada dos 11 agentes
1. Script — implementado no MVP.
2. Package — título e thumbnail.
3. Viral — pesquisa de tendências em fontes públicas/APIs permitidas.
4. Retention — análise de exportações CSV do YouTube Studio.
5. Edit — EDL a partir de transcrição/SRT.
6. Shorts — seleção de trechos de vídeos longos.
7. SEO — descrição e consultas de busca.
8. Plan — calendário editorial.
9. Comment — triagem e rascunho de respostas; publicação exige aprovação.
10. Chapters — capítulos com validação de timestamps.
11. Audit — diagnóstico do canal com uma prioridade principal.

## Próximas etapas recomendadas
1. Persistência de projetos e perfis de voz (PostgreSQL).
2. Autenticação e workspaces.
3. Implementar os agentes determinísticos de capítulos, edição e retenção.
4. Integrar YouTube Data API e OAuth para dados do próprio canal.
5. Integrar geração de áudio (ElevenLabs) e exportação para Remotion.
6. Aprovação humana obrigatória antes de responder comentários ou publicar.

## Referência
O conceito dos onze fluxos foi inspirado no repositório MIT:
https://github.com/Jakeschincariol/youtube-agent-skill

Este MVP é uma implementação independente, não uma cópia integral nem uma instalação automática do plugin original.
